import http.client
import json
import time
import timeit
import sys
import collections
from pygexf.gexf import *
import urllib.request, urllib.parse

# implement your data retrieval code here

# Define wait function
def wait():
    time.sleep(1)

#Ask user for API Key:
API_KEY =sys.argv[1]
print('Thank you for running! Processing...')

#Data retrieval with various attributes
values = {"key":API_KEY,
			"format":"json",
			"ordering":"-num_parts",
			"page_size":"1000",
			"min_parts":"1166"}

values1 = {"key":API_KEY,
			"format":"json",
			"page_size":"1000",
            "ordering":"-quantity"}

url = 'https://rebrickable.com/api/v3/lego/sets/?' + urllib.parse.urlencode(values)

response = urllib.request.urlopen(url)
data = json.loads(response.read().decode('utf-8','replace'))

#Get sets data
set_list = list(map(lambda x: str(x['set_num']) + ', ' + x['name'],data['results']))
set_list2=list(map(lambda x: str(x['set_num']),data['results']))
print('Done Extracting Sets')

#Get parts data
parts=[]
start = time.time() 
for x in set_list2:
    wait()  
    temp_parts=[]
    count=0
    url2 = 'https://rebrickable.com/api/v3/lego/sets/'+ x+'/parts/?'+urllib.parse.urlencode(values1)
    resp = urllib.request.urlopen(url2)
    data = json.loads(resp.read().decode('utf-8','replace'))
    for item in data['results']:
        temp_parts.append((item['set_num'],item['part']['part_num']+'-'+item['color']['rgb'],item['color']['rgb'],item['quantity'],item['part']['name'],))
    temp_parts.sort(key=lambda tup: tup[3], reverse=True)
    if len(temp_parts)>20:
        parts.extend(temp_parts[:20])
    else:
        parts.extend(temp_parts)  
end = time.time()
print(end - start)
print('Done Extracting Parts')

# complete auto grader functions for Q1.1.b,d
def min_parts():
    """
    Returns an integer value
    """
    # you must replace this with your own value
    return 1166

def lego_sets():
    """
    return a list of lego sets.
    this may be a list of any type of values
    but each value should represent one set

    e.g.,
    biggest_lego_sets = lego_sets()
    print(len(biggest_lego_sets))
    > 280
    e.g., len(my_sets)
    """
    # you must replace this line and return your own list
    return set_list

def gexf_graph(sets,parts):
    """
    return the completed Gexf graph object
    """
    # you must replace these lines and supply your own graph

    def hex_to_rgb(value):
        value = value.lstrip('#')
        lv = len(value)
        return tuple(int(value[i:i + lv // 3], 16) for i in range(0, lv, lv // 3))

    gexf = Gexf("Kent Ng", "Rebrickable Graph")
    graph=gexf.addGraph("undirected", "static", "Rebrickable Graph")
    
    nodes_in_graph=[]
    edges_in_graph=[]

    for item in sets:
        if item in nodes_in_graph:
            continue
        graph.addNode(id=item,label=item[1],r='0',g='0',b='0')
        nodes_in_graph.append(item)

    for item in parts:
        if item[1] in nodes_in_graph:
        	continue
        colour=hex_to_rgb(item[2])
        graph.addNode(id=item[1],label=item[4],r=str(colour[0]),g=str(colour[1]),b=str(colour[2]))
        nodes_in_graph.append(item[1])

    for item in parts:
        edge_id=str(item[0]+'-'+item[1])
        if edge_id in edges_in_graph:
    	    continue
        graph.addEdge(id=str(edge_id),source=str(item[0]),target=str(item[1]), weight=str(item[3]))
        edges_in_graph.append(edge_id)

    output_file=open("bricks_graph.gexf","wb")
    gexf.write(output_file)
    output_file.close()
    print('Done creating gexf file')
    return gexf.graphs[0]
    
# complete auto-grader functions for Q1.2.d

def avg_node_degree():
    """
    hardcode and return the average node degree
    (run the function called “Average Degree”) within Gephi
    """
    # you must replace this value with the avg node degree
    return 5.354

def graph_diameter():
    """
    hardcode and return the diameter of the graph
    (run the function called “Network Diameter”) within Gephi
    """
    # you must replace this value with the graph diameter
    return 8

def avg_path_length():
    """
    hardcode and return the average path length
    (run the function called “Avg. Path Length”) within Gephi
    :return:
    """
    # you must replace this value with the avg path length
    return 4.428